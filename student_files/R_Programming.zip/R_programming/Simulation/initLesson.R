
swirl_options(swirl_logging = TRUE)
# Put initialization code in this file.
