
swirl_options(swirl_logging = TRUE)
